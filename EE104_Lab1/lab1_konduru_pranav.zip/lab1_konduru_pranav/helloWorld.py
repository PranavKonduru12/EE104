#Defined function that prints Hello World!
def PrintHelloWorld():
    print("Hello World!")

PrintHelloWorld() # executed function here
